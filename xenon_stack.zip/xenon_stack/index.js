const express = require("express");
const path = require("path");
const ejs = require("ejs");
const Login = require("./src/mongodb");
const bodyParser = require("body-parser");
const bcrypt = require('bcrypt');
const app = express();

app.use(express.json());
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get("/", (req, res) => {
    res.render("login");
    // res.send("Hello");
});

app.get("/signup", (req, res) => {
    res.render("signup");
});
app.get("/login", (req, res) => {
    res.render("login");
});


app.post("/signup", async (req, res) => {
    try {
        const { username, password, confirmpassword, email, phone, dob } = req.body;

        // Log received data
        console.log("Received data:", { username, password, confirmpassword, email, phone, dob });

        // Validate that all required fields are provided
        if (!username || !password || !confirmpassword || !email) {
            return res.status(400).send("Username, email, and password are required.");
        }

        // Check that password and confirmPassword match
        if (password !== confirmpassword) {
            return res.status(400).send("Passwords do not match.");
        }

        // Validate password criteria
        const passwordRegex = /^(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>])(?=.*[a-zA-Z]).{8,}$/;
        if (!passwordRegex.test(password)) {
            return res.status(400).send("Password must be at least 8 characters long, contain at least one special character, and one digit.");
        }

        // Create a new user using the Mongoose model's `create` method
        const newUser = await Login.create({
            username,
            email,
            phone,
            dob,
            password // Note: Hash the password before saving to the database
        });
        console.log("User created:", newUser);

        // Render home page after successful signup
        res.render("home");
    } catch (err) {
        console.error("Error during signup:", err);
        // Handle different types of errors
        if (err.name === "ValidationError") {
            return res.status(400).send("Validation error: " + err.message);
        }
        // Handle unique constraint errors
        if (err.code === 11000) {
            return res.status(400).send("Username or email already exists.");
        }
        res.status(500).send("Error signing up");
    }
});

app.post("/login", async (req, res) => {
    try {
        const { username, password } = req.body;

        // Log received data
        console.log("Login attempt:", { username, password });

        // Find the user by username
        const user = await Login.findOne({ username });

        if (user) {
            // Compare the provided password with the hashed password in the database
            const isMatch = await bcrypt.compare(password, user.password);
            
            if (isMatch) {
                // Passwords match, login successful
                res.render("home");
            } else {
                // Passwords do not match
                res.status(400).send("Wrong password");
            }
        } else {
            // User not found
            res.status(400).send("Username not found");
        }
    } catch (err) {
        console.error("Error during login:", err);
        res.status(500).send("Error logging in");
    }
});

app.listen(3000, () => {
    console.log("Server running on port 3000");
});
